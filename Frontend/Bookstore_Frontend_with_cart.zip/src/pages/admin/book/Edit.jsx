import React from 'react'

function Edit() {
  return (
    <div>Edit</div>
  )
}

export default Edit